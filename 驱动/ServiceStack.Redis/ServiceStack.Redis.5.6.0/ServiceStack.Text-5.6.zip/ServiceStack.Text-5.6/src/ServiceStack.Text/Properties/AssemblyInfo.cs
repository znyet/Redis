using System.Runtime.InteropServices;

[assembly: ComVisible(false)]
[assembly: Guid("a352d4d3-df2a-4c78-b646-67181a6333a6")]
[assembly: System.Reflection.AssemblyVersion("5.0.0.0")]
