﻿//using NUnit.Framework;
//
//namespace ServiceStack.Text.Tests
//{
//    [SetUpFixture]
//    public class NUnitSetupFixture
//    {
//        [OneTimeSetUp]
//        public void Setup()
//        {
//#if NETCORE
//            ServiceStack.Memory.NetCoreMemory.Configure();
//#endif
//        }
//    }
//}