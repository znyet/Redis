namespace ServiceStack.Text.Tests.Support
{
    public class TableItem
    {
        public string Column1Data { get; set; }
        public string Column2Data { get; set; }
        public string Column3Data { get; set; }
        public string Column4Data { get; set; }
        public string Column5Data { get; set; }
    }
}