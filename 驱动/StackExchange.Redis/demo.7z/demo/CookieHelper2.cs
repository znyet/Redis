﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace Test
{
    public class CookieHelper2
    {
        /// <summary>
        /// 获取设置SessionID值
        /// </summary>
        /// <returns></returns>
        public static string GetCookie(string name)
        {
            var cookie = HttpContext.Current.Request.Cookies[name];
            if (cookie != null)
            {
                return cookie.Value.ToString();
            }
            else
            {
                var objId = ObjectId.NewId();
                SetCookie(name,objId);
                return objId;
            }
        }

        private static void SetCookie(string name,string value)
        {
            HttpCookie cokie = new HttpCookie(name);
            cokie.Value = value;
            cokie.Expires = System.DateTime.Now.AddDays(1);
            //cokie.Domain = "session.com";
            //cokie.Path = "/";
            cokie.HttpOnly = true;
            HttpContext.Current.Request.Cookies.Set(cokie);
            HttpContext.Current.Response.Cookies.Add(cokie);
        }

        public static void DeleteCookie(string name)
        {
            HttpCookie cokie = new HttpCookie(name);
            cokie.Expires = System.DateTime.Now.AddYears(-1);
            HttpContext.Current.Response.Cookies.Add(cokie);
        }
    }
}
